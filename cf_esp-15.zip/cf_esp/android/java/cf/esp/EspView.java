package cf.esp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

final class EspView extends View {
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();
    private final float[] cam = new float[6], a = new float[2], b = new float[2], tmp = new float[2];
    private boolean running;
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            invalidate();
            postOnAnimation(this);          // redraw on every vsync so the prediction runs at display rate
        }
    };

    EspView(Context c) {
        super(c);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        fill.setStyle(Paint.Style.FILL);
        text.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
    }

    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); running = true; postOnAnimation(tick); }
    @Override protected void onDetachedFromWindow() { running = false; super.onDetachedFromWindow(); }

    private static int alpha(int c, int al) { return Color.argb(al, Color.red(c), Color.green(c), Color.blue(c)); }

    private void label(Canvas c, String t, float cx, float baseY, float k, int col) {
        text.setTextSize(10.5f * k);
        text.setTextAlign(Paint.Align.CENTER);
        float w = text.measureText(t), h = 12f * k;
        rf.set(cx - w / 2 - 4 * k, baseY - h + 2 * k, cx + w / 2 + 4 * k, baseY + 3 * k);
        fill.setShader(null);
        fill.setColor(Color.argb(130, 8, 10, 12));
        c.drawRoundRect(rf, 3 * k, 3 * k, fill);
        text.setColor(col);
        c.drawText(t, cx, baseY, text);
    }

    @Override
    protected void onDraw(Canvas c) {
        final float W = getWidth(), H = getHeight();
        final float k = Math.max(1f, H / 540f);
        Snap s = Model.snap;
        if (!s.ok) {
            text.setTextSize(11f * k); text.setTextAlign(Paint.Align.LEFT); text.setColor(Color.WHITE);
            c.drawText("Wawer: " + s.status, 12f * k, H - 12f * k, text);
            return;
        }
        final int enemy = Cfg.enemyColor(), team = Cfg.teamColor();
        final boolean chams = Cfg.b("chams"), glow = Cfg.b("glow"), corner = Cfg.i("boxStyle") == 1;

        // --- time compensation: extrapolate the camera (and players) from the last real update to "now + display latency"
        float dt = (System.nanoTime() - s.tData) / 1e9f + Cfg.f("lat") / 1000f;
        dt = Math.max(0f, Math.min(0.12f, dt));
        Model.predictCam(s, dt, cam);
        final float fov = Model.effFov(s.fov, Cfg.f("fovScale"), Cfg.b("fovH"), W / H);

        if (Cfg.b("aim") && Cfg.b("showFov")) {
            stroke.setShader(null); stroke.setStrokeWidth(1.2f * k); stroke.setColor(Color.argb(110, 255, 255, 255));
            c.drawCircle(W / 2, H / 2, Cfg.f("aimFov"), stroke);
        }
        if (Cfg.b("crosshair")) { fill.setShader(null); fill.setColor(Color.argb(220, 255, 255, 255)); c.drawCircle(W / 2, H / 2, 2.2f * k, fill); }

        if (Cfg.b("esp")) {
            final float maxDist = Cfg.f("maxDist"), boxH = Cfg.f("boxH"), crouchH = Cfg.f("crouchH");
            final float fl = (float) Math.sqrt(cam[3] * cam[3] + cam[5] * cam[5]);
            for (Player p : s.players) {
                if (p.local() || p.dead()) continue;
                boolean mate = s.localTeam >= 1 && s.localTeam <= 2 && p.team == s.localTeam;
                if (mate && Cfg.b("teamCheck")) continue;
                float px = p.x + p.vx * dt, py = p.y, pz = p.z + p.vz * dt;
                float dx = px - cam[0], dy = py - cam[1], dz = pz - cam[2];
                float dist = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (dist > maxDist) continue;
                int col = mate ? team : enemy;
                float h = p.crouch() ? crouchH : boxH;
                boolean vis = Model.w2s(cam, fov, px, py, pz, W, H, a) && Model.w2s(cam, fov, px, py + h, pz, W, H, b);
                float bh = vis ? a[1] - b[1] : 0f;
                float cx = (a[0] + b[0]) * 0.5f;
                if (!vis || bh < 2f || cx < -W * 0.3f || cx > W * 1.3f) {
                    if (Cfg.b("offscreen") && fl > 1e-4f) drawArrow(c, W, H, k, col, dx, dz, cam[3] / fl, cam[5] / fl);
                    continue;
                }
                float bw = bh * 0.42f;
                float l = cx - bw / 2, r = cx + bw / 2, t = b[1], bt = a[1];

                if (chams) {                                   // stylised silhouette fill (an overlay cannot recolour the real model)
                    LinearGradient g = new LinearGradient(0, t, 0, bt, alpha(col, 120), alpha(col, 30), Shader.TileMode.CLAMP);
                    fill.setShader(g);
                    float hr = bh * 0.085f, hcx = cx, hcy = t + hr + bh * 0.02f;
                    c.drawCircle(hcx, hcy, hr, fill);
                    rf.set(cx - bw * 0.44f, t + bh * 0.16f, cx + bw * 0.44f, t + bh * 0.56f);
                    c.drawRoundRect(rf, bw * 0.16f, bw * 0.16f, fill);
                    rf.set(cx - bw * 0.40f, t + bh * 0.56f, cx - bw * 0.04f, bt);
                    c.drawRoundRect(rf, bw * 0.10f, bw * 0.10f, fill);
                    rf.set(cx + bw * 0.04f, t + bh * 0.56f, cx + bw * 0.40f, bt);
                    c.drawRoundRect(rf, bw * 0.10f, bw * 0.10f, fill);
                    fill.setShader(null);
                }
                stroke.setShader(null);
                if (glow) {
                    for (int i = 3; i >= 1; i--) {
                        stroke.setStrokeWidth((1.5f + i * 2.2f) * k);
                        stroke.setColor(alpha(col, 26));
                        if (corner) cornerBox(c, l, t, r, bt, bw, bh); else c.drawRoundRect(l, t, r, bt, 3 * k, 3 * k, stroke);
                    }
                }
                stroke.setStrokeWidth(1.6f * k);
                stroke.setColor(col);
                if (corner) cornerBox(c, l, t, r, bt, bw, bh); else c.drawRoundRect(l, t, r, bt, 3 * k, 3 * k, stroke);

                if (Cfg.b("headDot") && Model.w2s(cam, fov, px, py + (p.crouch() ? 1.2f : 1.62f), pz, W, H, tmp)) {
                    fill.setColor(Color.WHITE); c.drawCircle(tmp[0], tmp[1], Math.max(2f * k, bh * 0.028f), fill);
                    stroke.setStrokeWidth(1f * k); stroke.setColor(col); c.drawCircle(tmp[0], tmp[1], Math.max(2f * k, bh * 0.028f) + 1.5f * k, stroke);
                }
                if (Cfg.b("health")) {
                    float f = Math.max(0f, Math.min(1f, p.hp / 100f)), x = l - 6f * k, bwid = 3f * k;
                    fill.setShader(null); fill.setColor(Color.argb(170, 0, 0, 0));
                    rf.set(x - 1f * k, t - 1f * k, x + bwid + 1f * k, bt + 1f * k); c.drawRoundRect(rf, 2 * k, 2 * k, fill);
                    int hc = Color.rgb((int) (255 * (1 - f)), (int) (80 + 175 * f), 60);
                    fill.setColor(hc);
                    rf.set(x, bt - bh * f, x + bwid, bt); c.drawRoundRect(rf, 2 * k, 2 * k, fill);
                    if (Cfg.b("hpText") && p.hp < 100) {
                        text.setTextSize(9f * k); text.setTextAlign(Paint.Align.RIGHT); text.setColor(Color.WHITE);
                        c.drawText(String.valueOf(p.hp), x - 3f * k, Math.max(t + 8f * k, bt - bh * f + 4f * k), text);
                    }
                }
                if (Cfg.b("name") && !p.name.isEmpty()) label(c, p.name, cx, t - 6f * k, k, Color.WHITE);
                if (Cfg.b("dist")) label(c, (int) dist + "m", cx, bt + 14f * k, k, Color.rgb(205, 210, 218));
                if (Cfg.b("snap")) { stroke.setStrokeWidth(1f * k); stroke.setColor(alpha(col, 190)); c.drawLine(W / 2, H, cx, bt, stroke); }
            }
        }
        if (Cfg.b("radar") && Cfg.b("esp")) drawRadar(c, s, W, k, fov, W / H, enemy, team);
    }

    private void cornerBox(Canvas c, float l, float t, float r, float bt, float bw, float bh) {
        float lx = bw * 0.26f, ly = bh * 0.2f;
        c.drawLine(l, t, l + lx, t, stroke); c.drawLine(l, t, l, t + ly, stroke);
        c.drawLine(r, t, r - lx, t, stroke); c.drawLine(r, t, r, t + ly, stroke);
        c.drawLine(l, bt, l + lx, bt, stroke); c.drawLine(l, bt, l, bt - ly, stroke);
        c.drawLine(r, bt, r - lx, bt, stroke); c.drawLine(r, bt, r, bt - ly, stroke);
    }

    /** arrow on a ring around the crosshair pointing at an enemy that is behind / outside the screen */
    private void drawArrow(Canvas c, float W, float H, float k, int col, float dx, float dz, float fx, float fz) {
        float rx = fz, rz = -fx;
        float ang = (float) Math.atan2(dx * rx + dz * rz, dx * fx + dz * fz);          // 0 = ahead, +pi/2 = right
        float R = Math.min(W, H) * 0.40f, sx = W / 2 + (float) Math.sin(ang) * R, sy = H / 2 - (float) Math.cos(ang) * R;
        float ux = (float) Math.sin(ang), uy = -(float) Math.cos(ang), s = 11f * k;
        path.reset();
        path.moveTo(sx + ux * s, sy + uy * s);
        path.lineTo(sx - ux * s * 0.6f - uy * s * 0.8f, sy - uy * s * 0.6f + ux * s * 0.8f);
        path.lineTo(sx - ux * s * 0.6f + uy * s * 0.8f, sy - uy * s * 0.6f - ux * s * 0.8f);
        path.close();
        fill.setShader(null); fill.setColor(alpha(col, 215));
        c.drawPath(path, fill);
    }

    private void drawRadar(Canvas c, Snap s, float W, float k, float fovV, float aspect, int enemy, int team) {
        float R = 84f * k, ox = W - R - 18f * k, oy = R + 18f * k;
        fill.setShader(null); fill.setColor(Color.argb(120, 8, 10, 12)); c.drawCircle(ox, oy, R, fill);
        stroke.setShader(null); stroke.setStrokeWidth(1f * k);
        stroke.setColor(Color.argb(70, 255, 255, 255));
        c.drawCircle(ox, oy, R, stroke); c.drawCircle(ox, oy, R * 0.5f, stroke);
        c.drawLine(ox - R, oy, ox + R, oy, stroke); c.drawLine(ox, oy - R, ox, oy + R, stroke);
        float hf = (float) Math.atan(Math.tan(Math.toRadians(fovV) * 0.5) * aspect);      // half horizontal fov
        stroke.setColor(Color.argb(110, 90, 176, 255));
        c.drawLine(ox, oy, ox + (float) Math.sin(hf) * R, oy - (float) Math.cos(hf) * R, stroke);
        c.drawLine(ox, oy, ox - (float) Math.sin(hf) * R, oy - (float) Math.cos(hf) * R, stroke);
        float fl = (float) Math.sqrt(cam[3] * cam[3] + cam[5] * cam[5]);
        if (fl < 1e-4f) return;
        float fx = cam[3] / fl, fz = cam[5] / fl, rx = fz, rz = -fx, range = Cfg.f("radarRange");
        for (Player p : s.players) {
            if (p.dead()) continue;
            float x = 0, y = 0;
            if (!p.local()) {
                float dx = p.x - cam[0], dz = p.z - cam[2];
                x = (dx * rx + dz * rz) / range * R; y = -(dx * fx + dz * fz) / range * R;
                float d = (float) Math.sqrt(x * x + y * y);
                if (d > R - 4f * k) { x *= (R - 4f * k) / d; y *= (R - 4f * k) / d; }
            }
            boolean mate = s.localTeam >= 1 && p.team == s.localTeam;
            fill.setColor(p.local() ? Color.WHITE : (mate ? team : enemy));
            c.drawCircle(ox + x, oy + y, (p.local() ? 3.2f : 2.8f) * k, fill);
        }
    }
}
