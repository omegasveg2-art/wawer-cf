package cf.esp;

import java.util.ArrayList;

/** Pure Java (no android imports): protocol parser, camera prediction, world-to-screen. Unit-tested on the host. */
final class Player {
    int actor, team, hp, flags;
    float x, y, z, vx, vy, vz;
    String name = "";
    boolean local() { return (flags & 1) != 0; }
    boolean dead() { return (flags & 2) != 0; }
    boolean crouch() { return (flags & 4) != 0; }
}

final class Snap {
    boolean ok;
    String status = "";
    float cx, cy, cz, fx, fy, fz, fov = 60f;
    int localTeam;
    Player[] players = new Player[0];
    // derived by Model.publish
    long t, tData;                  // nanoTime of this line / of the last time the camera really changed
    float yaw, pitch;               // rad
    float yawRate, pitchRate;       // rad/s (smoothed)
    float vcx, vcy, vcz;            // camera velocity, units/s (smoothed)
}

final class Model {
    static volatile Snap snap = status("starting");

    static Snap status(String s) {
        Snap n = new Snap();
        n.status = s.length() > 90 ? s.substring(0, 90) : s;
        n.t = n.tData = System.nanoTime();
        return n;
    }

    private static float[] floats(String s, int n) {
        String[] p = s.split(",", -1);
        if (p.length != n) return null;
        float[] r = new float[n];
        for (int i = 0; i < n; i++) r[i] = Float.parseFloat(p[i]);
        return r;
    }

    /** S|status|cx,cy,cz|fx,fy,fz|fov|localTeam|actor,team,hp,flags,x,y,z,vx,vy,vz,name;...   or   N|status */
    static Snap parse(String line) {
        if (line.startsWith("N|")) return status(line.substring(2));
        try {
            String[] f = line.split("\\|", -1);
            if (f.length < 7 || !f[0].equals("S")) return status(line);
            float[] c = floats(f[2], 3), d = floats(f[3], 3);
            if (c == null || d == null) return status("bad line");
            Snap s = new Snap();
            s.ok = true;
            s.status = f[1];
            s.cx = c[0]; s.cy = c[1]; s.cz = c[2];
            s.fx = d[0]; s.fy = d[1]; s.fz = d[2];
            s.fov = Float.parseFloat(f[4]);
            s.localTeam = Integer.parseInt(f[5]);
            s.t = s.tData = System.nanoTime();
            float fl = (float) Math.sqrt(s.fx * s.fx + s.fy * s.fy + s.fz * s.fz);
            if (fl > 1e-6f) {
                s.yaw = (float) Math.atan2(s.fx, s.fz);
                s.pitch = (float) Math.asin(Math.max(-1f, Math.min(1f, s.fy / fl)));
            }
            ArrayList<Player> ps = new ArrayList<>();
            if (!f[6].isEmpty()) {
                for (String e : f[6].split(";")) {
                    String[] q = e.split(",", 11);
                    if (q.length < 11) continue;
                    Player p = new Player();
                    p.actor = Integer.parseInt(q[0]);
                    p.team = Integer.parseInt(q[1]);
                    p.hp = Integer.parseInt(q[2]);
                    p.flags = Integer.parseInt(q[3]);
                    p.x = Float.parseFloat(q[4]); p.y = Float.parseFloat(q[5]); p.z = Float.parseFloat(q[6]);
                    p.vx = Float.parseFloat(q[7]); p.vy = Float.parseFloat(q[8]); p.vz = Float.parseFloat(q[9]);
                    p.name = q[10];
                    ps.add(p);
                }
            }
            s.players = ps.toArray(new Player[0]);
            return s;
        } catch (NumberFormatException e) {
            return status("parse error: " + line);
        }
    }

    private static float wrap(float a) {
        final float P = (float) Math.PI;
        while (a > P) a -= 2 * P;
        while (a < -P) a += 2 * P;
        return a;
    }

    private static float clamp(float v, float m) { return v > m ? m : v < -m ? -m : v; }

    /**
     * Publishes a parsed snapshot. The core polls faster than the game refreshes the camera, so most lines are repeats:
     * rates are only recomputed when the camera really changed, and tData keeps the time of that last real change.
     */
    static void publish(Snap n) {
        Snap p = snap;
        if (n.ok && p.ok) {
            boolean same = Math.abs(n.cx - p.cx) < 1e-5f && Math.abs(n.cy - p.cy) < 1e-5f && Math.abs(n.cz - p.cz) < 1e-5f
                    && Math.abs(n.fx - p.fx) < 1e-6f && Math.abs(n.fy - p.fy) < 1e-6f && Math.abs(n.fz - p.fz) < 1e-6f;
            if (same) {
                n.tData = p.tData; n.yawRate = p.yawRate; n.pitchRate = p.pitchRate;
                n.vcx = p.vcx; n.vcy = p.vcy; n.vcz = p.vcz;
            } else {
                float dt = (n.t - p.tData) / 1e9f;
                if (dt > 0.002f && dt < 0.2f) {
                    final float a = 0.6f;
                    n.yawRate = a * clamp(wrap(n.yaw - p.yaw) / dt, 30f) + (1 - a) * p.yawRate;
                    n.pitchRate = a * clamp((n.pitch - p.pitch) / dt, 30f) + (1 - a) * p.pitchRate;
                    n.vcx = a * clamp((n.cx - p.cx) / dt, 25f) + (1 - a) * p.vcx;
                    n.vcy = a * clamp((n.cy - p.cy) / dt, 25f) + (1 - a) * p.vcy;
                    n.vcz = a * clamp((n.cz - p.cz) / dt, 25f) + (1 - a) * p.vcz;
                }
            }
        }
        snap = n;
    }

    /** out = {cx,cy,cz,fx,fy,fz}: camera moved forward in time by dt seconds using the smoothed rates. */
    static void predictCam(Snap s, float dt, float[] out) {
        float yaw = s.yaw + s.yawRate * dt;
        float pitch = Math.max(-1.55f, Math.min(1.55f, s.pitch + s.pitchRate * dt));
        float cp = (float) Math.cos(pitch);
        out[0] = s.cx + s.vcx * dt; out[1] = s.cy + s.vcy * dt; out[2] = s.cz + s.vcz * dt;
        out[3] = cp * (float) Math.sin(yaw); out[4] = (float) Math.sin(pitch); out[5] = cp * (float) Math.cos(yaw);
    }

    /** effective VERTICAL fov in degrees; optionally treat the game's number as horizontal. */
    static float effFov(float fov, float scale, boolean horiz, float aspect) {
        float f = fov * scale;
        if (!horiz) return f;
        double h = Math.toRadians(f);
        return (float) Math.toDegrees(2.0 * Math.atan(Math.tan(h * 0.5) / aspect));
    }

    /** Unity: left-handed, +Y up. right = up x fwd, roll ignored. c = {cx,cy,cz,fx,fy,fz}. out = {x, y}. */
    static boolean w2s(float[] c, float fovV, float wx, float wy, float wz, float W, float H, float[] out) {
        float fl = (float) Math.sqrt(c[3] * c[3] + c[4] * c[4] + c[5] * c[5]);
        if (fl < 1e-6f) return false;
        float fx = c[3] / fl, fy = c[4] / fl, fz = c[5] / fl;
        float rx = fz, rz = -fx;                                   // cross((0,1,0), f)
        float rl = (float) Math.sqrt(rx * rx + rz * rz);
        if (rl < 1e-6f) return false;
        rx /= rl; rz /= rl;
        float ux = fy * rz, uy = fz * rx - fx * rz, uz = -fy * rx; // cross(f, r), r.y = 0
        float dx = wx - c[0], dy = wy - c[1], dz = wz - c[2];
        float z = dx * fx + dy * fy + dz * fz;
        if (z < 0.05f) return false;
        float t = (float) Math.tan(Math.toRadians(fovV * 0.5));
        float aspect = W / H;
        out[0] = W * 0.5f + ((dx * rx + dz * rz) / (z * t * aspect)) * W * 0.5f;
        out[1] = H * 0.5f - ((dx * ux + dy * uy + dz * uz) / (z * t)) * H * 0.5f;
        return true;
    }

    /** convenience for tests: uses the snapshot's own camera and fov*scale (vertical). */
    static boolean w2s(Snap s, float fovScale, float wx, float wy, float wz, float W, float H, float[] out) {
        return w2s(new float[]{s.cx, s.cy, s.cz, s.fx, s.fy, s.fz}, s.fov * fovScale, wx, wy, wz, W, H, out);
    }
}
