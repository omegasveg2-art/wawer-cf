// g++ -std=c++17 -I../src test_aim.cpp ../src/aim.cpp ../src/game.cpp ../src/il2cpp.cpp ../src/mem.cpp
#include "../src/aim.h"
#include <cstdio>
#include <cassert>
static int fails = 0;
#define CHECK(x) do { if (!(x)) { printf("FAIL %d: %s\n", __LINE__, #x); fails++; } } while (0)
int main() {
    Snapshot s; s.valid = true; s.cam.pos = {0, 1.6f, 0}; s.cam.fwd = {0, 0, 1}; s.cam.fovY = 70; s.localTeam = 1;
    PlayerInfo e; e.actor = 5; e.team = 2; e.pos = {3, 0, 12}; s.players.push_back(e);
    AimCfg c; c.on = true; c.fovPx = 2000; c.smooth = 1.f; c.ppd = 10.f; c.maxStep = 1e6f; c.leadMs = 0;
    AimOut o = aim_step(s, c, 0);
    CHECK(o.has && o.actor == 5 && o.dx > 0);                       // target is to the right -> drag right
    // apply the full correction as a camera rotation, target must land on screen centre
    float dyaw = o.dx / c.ppd, dpitch = -o.dy / c.ppd;               // deg
    const float D = 3.14159265f / 180.f;
    float yaw = dyaw * D, pitch = dpitch * D;
    s.cam.fwd = {std::cos(pitch) * std::sin(yaw), std::sin(pitch), std::cos(pitch) * std::cos(yaw)};
    float x, y;
    Vec3 pt = bone_point(e, 0, 0);
    CHECK(w2s(s.cam, pt, c.W, c.H, x, y));
    printf("after full aim step target at %.2f %.2f (centre %.0f %.0f)\n", x, y, c.W / 2, c.H / 2);
    CHECK(std::fabs(x - c.W / 2) < 0.5f && std::fabs(y - c.H / 2) < 0.5f);
    // teammate must be ignored, dead ignored, out-of-fov ignored
    s.cam.fwd = {0, 0, 1}; s.players[0].team = 1; CHECK(!aim_step(s, c, 0).has);
    s.players[0].team = 2; s.players[0].dead = true; CHECK(!aim_step(s, c, 0).has);
    s.players[0].dead = false; c.fovPx = 5; CHECK(!aim_step(s, c, 0).has);
    c.on = false; c.fovPx = 2000; CHECK(!aim_step(s, c, 0).has);
    printf(fails ? "%d FAILED\n" : "aim ok\n", fails);
    return fails != 0;
}
