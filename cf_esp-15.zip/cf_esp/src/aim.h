// aim assist math (pure, host-testable): picks a target near the crosshair and returns a touch delta in px.
#pragma once
#include "game.h"

struct AimCfg {
    bool on = false;
    int key = 0;                 // 0 always, 1 hold Vol-Down, 2 hold Vol-Up
    float fovPx = 180.f;         // circle radius around screen centre
    float smooth = 0.12f;        // fraction of the angular error corrected per frame
    float ppd = 9.f;             // touch px per degree of camera rotation (calibrate!)
    float maxStep = 40.f;        // px per frame cap
    int bone = 0;                // 0 head, 1 neck, 2 chest
    bool invY = false;
    float sx = 0.62f, sy = 0.40f;    // where the virtual finger starts (fraction of screen)
    float W = 2400.f, H = 1080.f;    // logical screen
    int rot = 1;                     // Surface rotation 0..3
    float fovScale = 1.f;
    bool fovHoriz = false;
    bool teamCheck = true;
    float maxDist = 150.f;
    float leadMs = 60.f;             // target lead (velocity * lead)
};

struct AimOut {
    bool has = false;
    int actor = 0;
    float dx = 0, dy = 0;        // px to move the virtual finger this frame
    float errDeg = 0;
};

Vec3 bone_point(const PlayerInfo& p, int bone, float leadSec);
AimOut aim_step(const Snapshot& s, const AimCfg& c, int stickyActor);
