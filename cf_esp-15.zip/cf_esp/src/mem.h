// process memory access. Linux-generic (process_vm_readv + /proc/pid/mem fallback), no android deps.
#pragma once
#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>

struct Region {
    uint64_t start = 0, end = 0, pgoff = 0;
    bool r = false, w = false, x = false;
    std::string path;
};

struct IMem {
    virtual ~IMem() = default;
    virtual bool read(uint64_t addr, void* out, size_t n) = 0;   // false + zeroed buffer on failure
    virtual std::vector<Region> regions() = 0;
};

// arm64 heap pointers can carry a tag in the top byte (TBI/MTE) -- strip before any syscall / compare
inline uint64_t untag(uint64_t p) { return p & 0x00FFFFFFFFFFFFFFull; }
inline bool plausible_ptr(uint64_t p) { p = untag(p); return p >= 0x10000 && p < 0x0000800000000000ull; }

template <class T> inline T rdv(IMem& m, uint64_t a) { T v{}; m.read(a, &v, sizeof(T)); return v; }
inline uint64_t rdp(IMem& m, uint64_t a) { return untag(rdv<uint64_t>(m, a)); }   // pointer read, tag stripped
inline uint32_t rd32(IMem& m, uint64_t a) { return rdv<uint32_t>(m, a); }
inline uint8_t  rd8 (IMem& m, uint64_t a) { return rdv<uint8_t>(m, a); }
inline float    rdf (IMem& m, uint64_t a) { return rdv<float>(m, a); }

class Proc : public IMem {
public:
    int pid = 0;
    // pid of the main process whose argv[0] contains `needle` (case-insensitive), skipping ":service" children and ourselves
    static int find_pid(const std::string& needle);
    bool attach(int p);
    void detach();
    bool alive() const;
    bool read(uint64_t addr, void* out, size_t n) override;
    std::vector<Region> regions() override;
    uint64_t module_base(const char* name);   // lowest mapping whose path contains `name`, 0 if none
    ~Proc() override { detach(); }
private:
    int memfd_ = -1;
    bool use_fd_ = false;
};
