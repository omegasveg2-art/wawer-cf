#include "aim.h"
#include <algorithm>

Vec3 bone_point(const PlayerInfo& p, int bone, float lead) {
    static const float H[3] = {1.62f, 1.45f, 1.15f};
    float h = H[bone < 0 ? 0 : bone > 2 ? 2 : bone];
    if (p.crouch) h *= 0.78f;
    return {p.pos.x + p.vel.x * lead, p.pos.y + h, p.pos.z + p.vel.z * lead};
}

AimOut aim_step(const Snapshot& s, const AimCfg& c, int sticky) {
    AimOut o;
    if (!c.on || !s.valid) return o;
    Cam cam = s.cam;
    cam.fovY = eff_fov(cam.fovY, c.fovScale, c.fovHoriz, c.W / c.H);
    const float cx = c.W * 0.5f, cy = c.H * 0.5f;
    float best = 1e9f;
    const PlayerInfo* bp = nullptr;
    Vec3 bpt;
    for (auto& p : s.players) {
        if (p.local || p.dead) continue;
        bool mate = s.localTeam >= 1 && s.localTeam <= 2 && p.team == s.localTeam;
        if (mate && c.teamCheck) continue;
        if (len(p.pos - cam.pos) > c.maxDist) continue;
        Vec3 pt = bone_point(p, c.bone, c.leadMs / 1000.f);
        float sx, sy;
        if (!w2s(cam, pt, c.W, c.H, sx, sy)) continue;
        float d = std::sqrt((sx - cx) * (sx - cx) + (sy - cy) * (sy - cy));
        bool st = p.actor == sticky;
        if (d > c.fovPx * (st ? 1.3f : 1.f)) continue;
        if (st) d *= 0.5f;                     // hysteresis: keep the current target
        if (d < best) { best = d; bp = &p; bpt = pt; }
    }
    if (!bp) return o;

    const float R2D = 180.f / 3.14159265f;
    Vec3 f = norm(cam.fwd), dv = norm(bpt - cam.pos);
    float curYaw = std::atan2(f.x, f.z), curPitch = std::asin(std::max(-1.f, std::min(1.f, f.y)));
    float tYaw = std::atan2(dv.x, dv.z), tPitch = std::asin(std::max(-1.f, std::min(1.f, dv.y)));
    float dyaw = wrap_pi(tYaw - curYaw) * R2D, dpitch = (tPitch - curPitch) * R2D;
    o.errDeg = std::sqrt(dyaw * dyaw + dpitch * dpitch);
    float dx = dyaw * c.ppd * c.smooth;
    float dy = -dpitch * c.ppd * c.smooth * (c.invY ? -1.f : 1.f);
    float m = std::sqrt(dx * dx + dy * dy);
    if (m > c.maxStep) { dx *= c.maxStep / m; dy *= c.maxStep / m; }
    if (m < 0.25f) { dx = dy = 0; }            // dead zone
    o.has = true; o.actor = bp->actor; o.dx = dx; o.dy = dy;
    return o;
}
