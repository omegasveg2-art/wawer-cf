// cf_core: root, read-only memory reader + optional aim assist (virtual touch). Talks to the overlay APK over stdin/stdout.
// usage: cf_core [-p <pkg substring>] [--base 0x<libil2cpp base>]
// out:  S|ok|cx,cy,cz|fx,fy,fz|fov|localTeam|actor,team,hp,flags,x,y,z,vx,vy,vz,name;...   (flags: 1 local, 2 dead, 4 crouch)
//       N|status
// in:   C|aim=1,key=1,fov=180,smooth=0.12,ppd=9,maxstep=40,bone=0,invy=0,sx=0.62,sy=0.4,W=2400,H=1080,rot=1,fs=1,fh=0,team=1,maxd=150,lead=60
#include "aim.h"
#include "inject.h"
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <linux/input.h>
#include <mutex>
#include <string>
#include <thread>
#include <unistd.h>

static std::mutex g_mu;
static AimCfg g_cfg;

static void apply_kv(AimCfg& c, const std::string& k, float v) {
    if (k == "aim") c.on = v != 0; else if (k == "key") c.key = (int)v; else if (k == "fov") c.fovPx = v;
    else if (k == "smooth") c.smooth = v; else if (k == "ppd") c.ppd = v; else if (k == "maxstep") c.maxStep = v;
    else if (k == "bone") c.bone = (int)v; else if (k == "invy") c.invY = v != 0; else if (k == "sx") c.sx = v;
    else if (k == "sy") c.sy = v; else if (k == "W") c.W = v; else if (k == "H") c.H = v; else if (k == "rot") c.rot = (int)v;
    else if (k == "fs") c.fovScale = v; else if (k == "fh") c.fovHoriz = v != 0; else if (k == "team") c.teamCheck = v != 0;
    else if (k == "maxd") c.maxDist = v; else if (k == "lead") c.leadMs = v;
}

static void stdin_loop() {
    char line[1024];
    while (fgets(line, sizeof line, stdin)) {
        if (line[0] != 'C' || line[1] != '|') continue;
        AimCfg c;
        { std::lock_guard<std::mutex> l(g_mu); c = g_cfg; }
        char* save = nullptr;
        for (char* t = strtok_r(line + 2, ",\r\n", &save); t; t = strtok_r(nullptr, ",\r\n", &save)) {
            char* eq = strchr(t, '=');
            if (!eq) continue;
            *eq = 0;
            apply_kv(c, t, strtof(eq + 1, nullptr));
        }
        std::lock_guard<std::mutex> l(g_mu);
        g_cfg = c;
    }
    _exit(0);                                    // parent (APK) closed our stdin -> quit
}

static std::string clean(const char* s) {
    std::string o;
    for (; *s; s++) o.push_back((isalnum((unsigned char)*s) || *s == '_' || *s == '.' || *s == '-' || *s == ' ') ? *s : '_');
    return o;
}

int main(int argc, char** argv) {
    std::string pkg = "counterflame";
    uint64_t baseOverride = 0;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-p") && i + 1 < argc) pkg = argv[++i];
        else if (!strcmp(argv[i], "--base") && i + 1 < argc) baseOverride = strtoull(argv[++i], nullptr, 16);
    }
    if (getuid() != 0) { printf("N|needs root\n"); return 1; }
    setvbuf(stdout, nullptr, _IOLBF, 0);
    std::thread(stdin_loop).detach();

    Proc proc;
    Game* game = nullptr;
    Snapshot snap;
    Touch touch;
    Keys keys;
    bool touchOk = touch.init(), keysOk = keys.init();
    std::string status = "waiting for game";
    int sticky = 0;
    float fx = 0, fy = 0;                          // virtual finger position (px)
    auto lastTry = std::chrono::steady_clock::now() - std::chrono::seconds(10);
    auto fingerSince = lastTry;

    for (;;) {
        if (game && !proc.alive()) { delete game; game = nullptr; proc.detach(); status = "game closed"; touch.lift(); }
        if (!game && std::chrono::steady_clock::now() - lastTry > std::chrono::seconds(2)) {
            lastTry = std::chrono::steady_clock::now();
            int pid = Proc::find_pid(pkg);
            if (pid) {
                proc.attach(pid);
                uint64_t base = baseOverride ? baseOverride : proc.module_base("libil2cpp.so");
                if (base) game = new Game(proc, base);
                else { proc.detach(); status = "libil2cpp.so not mapped (use --base)"; }
            }
        }
        if (!game) { printf("N|%s\n", status.c_str()); std::this_thread::sleep_for(std::chrono::milliseconds(500)); continue; }
        if (!game->update(snap)) { touch.lift(); printf("N|%s\n", game->status()); std::this_thread::sleep_for(std::chrono::milliseconds(100)); continue; }

        std::string out = "S|ok|";
        char b[320];
        snprintf(b, sizeof b, "%.3f,%.3f,%.3f|%.4f,%.4f,%.4f|%.2f|%d|", snap.cam.pos.x, snap.cam.pos.y, snap.cam.pos.z,
                 snap.cam.fwd.x, snap.cam.fwd.y, snap.cam.fwd.z, snap.cam.fovY, (int)snap.localTeam);
        out += b;
        bool first = true;
        for (auto& p : snap.players) {
            snprintf(b, sizeof b, "%s%d,%d,%d,%d,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,", first ? "" : ";", p.actor, (int)p.team, p.hp,
                     (p.local ? 1 : 0) | (p.dead ? 2 : 0) | (p.crouch ? 4 : 0), p.pos.x, p.pos.y, p.pos.z, p.vel.x, p.vel.y, p.vel.z);
            out += b; out += clean(p.name);
            first = false;
        }
        out += "\n";
        if (fputs(out.c_str(), stdout) < 0) return 0;     // reader gone

        // ---- aim assist
        AimCfg c;
        { std::lock_guard<std::mutex> l(g_mu); c = g_cfg; }
        if (keysOk) { keys.poll(); keys.grab(c.on && c.key != 0); }
        bool armed = c.on && touchOk && (c.key == 0 || (c.key == 1 && keys.down(KEY_VOLUMEDOWN)) || (c.key == 2 && keys.down(KEY_VOLUMEUP)));
        AimOut a = armed ? aim_step(snap, c, sticky) : AimOut();
        if (a.has) {
            sticky = a.actor;
            auto now = std::chrono::steady_clock::now();
            if (!touch.active() || now - fingerSince > std::chrono::seconds(2) || fx < 0.05f * c.W || fx > 0.95f * c.W || fy < 0.05f * c.H || fy > 0.95f * c.H) {
                if (touch.active()) touch.lift();       // re-seed the finger so it never drifts off the look area
                fx = c.sx * c.W; fy = c.sy * c.H; fingerSince = now;
            }
            fx += a.dx; fy += a.dy;
            touch.move(fx, fy, c.W, c.H, c.rot);
        } else { sticky = 0; touch.lift(); }
        std::this_thread::sleep_for(std::chrono::milliseconds(4));
    }
}
