#include "inject.h"
#include <algorithm>
#include <cstring>
#include <dirent.h>
#include <fcntl.h>
#include <linux/input.h>
#include <string>
#include <sys/ioctl.h>
#include <unistd.h>

static bool has_bit(const unsigned long* a, int b) { return a[b / (8 * sizeof(long))] & (1ul << (b % (8 * sizeof(long)))); }

bool Touch::init() {
    DIR* d = opendir("/dev/input");
    if (!d) return false;
    while (dirent* e = readdir(d)) {
        if (strncmp(e->d_name, "event", 5)) continue;
        std::string p = std::string("/dev/input/") + e->d_name;
        int fd = open(p.c_str(), O_RDWR | O_NONBLOCK);
        if (fd < 0) continue;
        unsigned long abs[(ABS_MAX + 1) / (8 * sizeof(long)) + 1] = {0};
        unsigned long prop[(INPUT_PROP_MAX + 1) / (8 * sizeof(long)) + 1] = {0};
        ioctl(fd, EVIOCGBIT(EV_ABS, sizeof abs), abs);
        ioctl(fd, EVIOCGPROP(sizeof prop), prop);
        if (!has_bit(abs, ABS_MT_POSITION_X) || !has_bit(abs, ABS_MT_SLOT) || !has_bit(prop, INPUT_PROP_DIRECT)) { close(fd); continue; }
        input_absinfo ax{}, ay{}, as{}, ai{};
        ioctl(fd, EVIOCGABS(ABS_MT_POSITION_X), &ax);
        ioctl(fd, EVIOCGABS(ABS_MT_POSITION_Y), &ay);
        ioctl(fd, EVIOCGABS(ABS_MT_SLOT), &as);
        ioctl(fd, EVIOCGABS(ABS_MT_TRACKING_ID), &ai);
        fd_ = fd; minx_ = ax.minimum; maxx_ = ax.maximum; miny_ = ay.minimum; maxy_ = ay.maximum;
        slot_ = as.maximum;                       // highest slot: unlikely to collide with real fingers
        idMax_ = ai.maximum > 100 ? ai.maximum : 65535;
        tid_ = 4000;
        break;
    }
    closedir(d);
    return fd_ >= 0;
}

void Touch::emit(int type, int code, int value) {
    input_event ev;
    memset(&ev, 0, sizeof ev);
    ev.type = (unsigned short)type; ev.code = (unsigned short)code; ev.value = value;
    if (write(fd_, &ev, sizeof ev) < 0) { /* ignore */ }
}

void Touch::move(float lx, float ly, float W, float H, int rot) {
    if (fd_ < 0) return;
    float Wp = std::min(W, H), Hp = std::max(W, H), px, py;      // physical portrait size in px
    switch (rot) {                                               // inverse of the logical <- panel mapping
        case 1:  px = Wp - ly; py = lx; break;
        case 2:  px = Wp - lx; py = Hp - ly; break;
        case 3:  px = ly;      py = Hp - lx; break;
        default: px = lx;      py = ly;
    }
    px = std::max(0.f, std::min(Wp, px)); py = std::max(0.f, std::min(Hp, py));
    int rx = minx_ + (int)(px / Wp * (maxx_ - minx_)), ry = miny_ + (int)(py / Hp * (maxy_ - miny_));
    emit(EV_ABS, ABS_MT_SLOT, slot_);
    if (!down_) { tid_ = tid_ >= idMax_ ? 4000 : tid_ + 1; emit(EV_ABS, ABS_MT_TRACKING_ID, tid_); down_ = true; }
    emit(EV_ABS, ABS_MT_POSITION_X, rx);
    emit(EV_ABS, ABS_MT_POSITION_Y, ry);
    emit(EV_SYN, SYN_REPORT, 0);
}

void Touch::lift() {
    if (fd_ < 0 || !down_) return;
    emit(EV_ABS, ABS_MT_SLOT, slot_);
    emit(EV_ABS, ABS_MT_TRACKING_ID, -1);
    emit(EV_SYN, SYN_REPORT, 0);
    down_ = false;
}

Touch::~Touch() { lift(); if (fd_ >= 0) close(fd_); }

bool Keys::init() {
    DIR* d = opendir("/dev/input");
    if (!d) return false;
    while (dirent* e = readdir(d)) {
        if (strncmp(e->d_name, "event", 5)) continue;
        std::string p = std::string("/dev/input/") + e->d_name;
        int fd = open(p.c_str(), O_RDONLY | O_NONBLOCK);
        if (fd < 0) continue;
        unsigned long key[(KEY_MAX + 1) / (8 * sizeof(long)) + 1] = {0};
        ioctl(fd, EVIOCGBIT(EV_KEY, sizeof key), key);
        if (has_bit(key, KEY_VOLUMEDOWN) || has_bit(key, KEY_VOLUMEUP)) fds_.push_back(fd); else close(fd);
    }
    closedir(d);
    return !fds_.empty();
}

void Keys::poll() {
    for (int fd : fds_) {
        input_event ev[32];
        ssize_t n;
        while ((n = read(fd, ev, sizeof ev)) > 0)
            for (size_t i = 0; i < (size_t)n / sizeof(input_event); i++)
                if (ev[i].type == EV_KEY) {
                    if (ev[i].code == KEY_VOLUMEDOWN) dn_[0] = ev[i].value != 0;
                    else if (ev[i].code == KEY_VOLUMEUP) dn_[1] = ev[i].value != 0;
                }
    }
}

bool Keys::down(int code) const { return code == KEY_VOLUMEDOWN ? dn_[0] : code == KEY_VOLUMEUP ? dn_[1] : false; }

void Keys::grab(bool on) {
    if (on == grabbed_) return;
    for (int fd : fds_) ioctl(fd, EVIOCGRAB, on ? 1 : 0);
    grabbed_ = on;
}

Keys::~Keys() { grab(false); for (int fd : fds_) close(fd); }
